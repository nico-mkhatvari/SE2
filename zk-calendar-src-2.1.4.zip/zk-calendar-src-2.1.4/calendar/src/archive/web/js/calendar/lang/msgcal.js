/* msgcal.js

	Purpose:
		
	Description:
		
	History:
		Wed Mar 18 18:36:47     2009, Created by jumperchen

Copyright (C) 2009 Potix Corporation. All Rights Reserved.

This program is distributed under GPL Version 2.0 in the hope that
it will be useful, but WITHOUT ANY WARRANTY.
*/
msgcal = {};
msgcal.dayMORE = "+{0} more";
msgcal.monthMORE = "+{0} more";